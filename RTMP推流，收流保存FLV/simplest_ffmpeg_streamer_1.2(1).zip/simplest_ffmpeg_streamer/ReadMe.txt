﻿最简单的基于FFmpeg的推流器（推送RTMP）
Simplest FFmpeg Streamer (Send RTMP)

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020

本例子实现了推送本地视频至流媒体服务器（以RTMP为例）。
是使用FFmpeg进行流媒体推送最简单的教程。

This example stream local media files to streaming media 
server (Use RTMP as example). 
It's the simplest FFmpeg streamer.